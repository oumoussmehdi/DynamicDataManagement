import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import download.WebService;
import parsers.ParseResultsForWS;
import parsers.WebServiceDescription;


public class Main {
	static DBConnection dbconn = new DBConnection();

	public static final void main(String[] args) throws Exception{

		List<String> params = Arrays.asList("http://musicbrainz.org/ws/1/artist/?name=", null);

		System.out.println("NB: If you get a 503 error (server failure), please rerun the program. ");
		System.out.println("The next artists were tested : ");
		System.out.println("Michael Jackson, Nas, Frank Sinatra, Leonard Cohen");
		System.out.println("-- - - - - - - - - -- - - - -- - -- - - - ");
		System.out.println("Please ! enter a singer's name : ");

		Scanner scan = new Scanner(System.in); 
		String user_input = scan.nextLine();

		String query = "getArtistInfoByName("+user_input+", ?artistId, ?b, ?e)"
				+ "#getAlbumInfoByArtistId(?artistId, ?albumId, ?albumName)"
				+ "#getSongsByAlbumID(?albumId, songTitle, year)";

		System.out.println("Query to process : ");
		System.out.println(query);

		/**
		 * Query processing:
		 * */
		String[] inputs = process_query(query);
		String input = inputs[0]; // singer name
		String webservice1 = "mb_"+ inputs[1];
		String webservice2 = "mb_"+ inputs[2];
		String webservice3 = "mb_"+ inputs[3];


		//Testing with loading the description WS
		WebService ws = WebServiceDescription.loadDescription(webservice1);
		String fileWithCallResult = ws.getCallResult(input);
		System.out.println("The call is   **"+fileWithCallResult+"**");
		String fileWithTransfResults=ws.getTransformationResult(fileWithCallResult);
		ArrayList<String[]>  listOfTupleResult= ParseResultsForWS.showResults(fileWithTransfResults, ws);


		System.out.println("The tuple results of "+webservice1+" are :");
		for(String [] tuple:listOfTupleResult){
			String result = "(";
			int i = tuple.length;
			for(String t:tuple){
				if(i==1){
					result += "\""+t+"\"";
					//System.out.print(t);
				}
				else{
					result += "\""+t+"\""+", ";
					//System.out.print(t+", ");
				}
				i--;
			}
			result += ") ";
			System.out.println(result);
			db_insert(ws.getName(), result);		
		}

		Statement stmt = (Statement) dbconn.getInstance().createStatement();
		String sql;
		sql = "select * from mb_getArtistInfoByName where artistName = '" + input + "';";
		ResultSet rs = stmt.executeQuery(sql);

		/** Call of second webservice :  */
		String artistId = null;
		while(rs.next()){
			artistId = rs.getString("artistId");
			call_webservice(artistId, webservice2);
		}

		/** Call of third webservice :  */
		sql = "select * from mb_getAlbumInfoByArtistId where artistId = '" + artistId + "';";
		ResultSet rs3 = stmt.executeQuery(sql);
		String albumId = null;
		while(rs3.next()){

			albumId = rs3.getString("albumId");
			call_webservice(albumId, webservice3);
		}


		System.out.println("****************************************");
		System.out.println("*************Final Results**************");
		System.out.println("****************************************");

		sql = " select artist.artistName, album.albumName, song.recordingName from mb_getAlbumInfoByArtistId album, mb_getArtistInfoByName artist,mb_getSongsByAlbumID song  where album.artistId = artist.artistId and album.albumId=song.releaseID ;";
		ResultSet final_rs = stmt.executeQuery(sql);
		while(final_rs.next()){

			String name = final_rs.getString("artistName");
			String album = final_rs.getString("albumName");
			String song = final_rs.getString("recordingName");

			System.out.println("("+name +", "+ album +", "+ song +")");		
		}
	}

	/**
	 * process the input querey
	 * @param query
	 * @return
	 */
	private static String[] process_query(String query) {
		String[] s = new String[4];

		String[] temp = query.split("#");
		String t1 = temp[0];

		String regEx = "(\\()(.*?)(\\,)";
		Matcher mat = Pattern.compile(regEx).matcher(temp[0]);
		if (mat.find()) // (Pattern.compile(regexSt3).matcher(tab[i]).matches()))
		{
			s[0] = mat.group(2);
		}
		s[1] = temp[0].split("\\(")[0];
		s[2] = temp[1].split("\\(")[0];
		s[3] = temp[2].split("\\(")[0];

		return s;
	}

	/**
	 * Execute the call of the webservice to get the answer from the server
	 * @param call
	 * @param webservice
	 * @throws Exception
	 */
	private static void call_webservice(String call, String webservice) throws Exception {
		WebService ws=WebServiceDescription.loadDescription(webservice);
		String fileWithCallResult = ws.getCallResult(call);
		System.out.println("The call is   **"+fileWithCallResult+"**");
		String fileWithTransfResults = ws.getTransformationResult(fileWithCallResult);
		ArrayList<String[]>  listOfTupleResult = ParseResultsForWS.showResults(fileWithTransfResults, ws);


		System.out.println("The tuple results are ");
		for(String [] tuple:listOfTupleResult){
			String result = "";
			if (webservice.contentEquals("mb_getAlbumInfoByArtistId"))
				result = "(";
			else
				result = "(\""+call+"\",";
			int i = tuple.length;
			for(String t:tuple){
				if(i==1){
					result += "\""+t+"\"";
					//System.out.print(t);
				}
				else{
					result += "\""+t+"\""+", ";
					//System.out.print(t+", ");
				}
				i--;
			}
			result += ") ";
			System.out.println(result);
			db_insert(ws.getName(), result);		
		}
	}


	/**
	 * Insert extracted information into the database
	 * @param ws_name
	 * @param result
	 * @throws SQLException
	 */
	static void db_insert(String ws_name, String result) throws SQLException {

		Connection conn = dbconn.getInstance();

		Statement stmt = (Statement) conn.createStatement();
		String query;
		query = "INSERT INTO "+ws_name+" VALUES ";
		query += result;
		query += ";";	
		int rs = stmt.executeUpdate(query);
	}

}
